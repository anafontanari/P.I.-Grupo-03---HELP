Projeto Integrador VI: Desenvolvimento de Sistemas Orientado a Dispositivos Móveis e Baseados na Web - 2ª Entrega

Grupo 03 - Integrantes:

Ana Amália Fontanari Barboza
Ítalo Maranha Silva
Lucas Santana dos Santos
Mariana Loureiro Aguiar da Silva
Samuel Siqueira Pereira
Vivian Ingrid Lopes da Silva

Link do youtube para acessar a gravação explicativa:
?????????????????????

Instalação:
  Por se tratar de um web site não será necessário nenhuma instalação, basta acessar o site e realizar o login.

Utilização do site desenvolvido:
  A aplicação desenvolvida para a empresa HELP foi um web site, onde o usuário, seja ele cliente ou prestador de serviço, pode se cadastrar e utilizar os serviços oferecidos pela empresa. 
  A jornada do usuário - cliente segue os seguintes passos:

    - Na tela principal do web site, clicar no botão "Login". O site o direcionará para a página de login, onde deverão ser inseridos os dados de usuário e senha. Em seguida, deve-se clicar no botão "Sign In";
    - Ainda na tela de login, caso o usuário clique no botão "Esqueceu a senha?", um pop-up abrirá com a mensagem de que a nova senha foi enviada para o e-mail cadastrado;
    -Após realizar o login, o usuário será direcionado para a tela do cliente, onde terá a opção de contratar o acompanhante pela sua localização, basta clicar no botão "Localização";
    - Em seguida, será direcionado para a tela de busca para realizar a contratação, devendo inserir alguns dados como período da contratação, data e hora e a forma de busca do acompanhante. Deverá selecionar a opção "Usar minha localização" e clicar no botão "Localizar";
    - Na tela para seleção do acompanhante, o usuário deverá escolher o acompanhante que aparecer no mapa e clicar no botão "Salvar";
    - O usuário será direcionado para a tela de pagamento, na qual deverá escolher a foram de pagamento e clicar no botão "Salvar";
    - Em seguida, um pop-up abrirá com o mensagens de que os dados para o pagamento foram enviados para o e-mail cadastrado.




